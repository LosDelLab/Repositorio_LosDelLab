//
//  Taler.h
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/1/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>

@interface Taler : RLMObject

@property (nonatomic, strong) NSString *marca;
@property (nonatomic) int ano;
@property (nonatomic, strong) NSString *cliente;
@property (nonatomic, strong) NSString *descripcion;
@property (nonatomic) float montoTotal;
@property NSDate* fechaTrabajo;
@end
RLM_ARRAY_TYPE(Taler);