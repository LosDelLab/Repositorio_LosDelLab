//
//  WelcomeViewController.h
//  Tarea1_David_Salas
//
//  Created by Enrique on 6/29/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

- (IBAction)showHistory:(id)sender;

- (IBAction)addNewJob:(id)sender;
@end
