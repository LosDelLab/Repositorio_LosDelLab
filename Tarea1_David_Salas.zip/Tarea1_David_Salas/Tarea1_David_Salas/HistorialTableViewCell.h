//
//  HistorialTableViewCell.h
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/3/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistorialTableViewCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *txtFecha;

@property (weak, nonatomic) IBOutlet UILabel *txtMarca;
@property (weak, nonatomic) IBOutlet UILabel *txtCliente;
@property (weak, nonatomic) IBOutlet UITextView *txtDetalle;

@end
