//
//  NewJobViewController.m
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/1/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import "NewJobViewController.h"
#import "Taler.h"



@interface NewJobViewController ()


@end

@implementation NewJobViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //llamamos al metodo inicializar
    [self initialize];
    
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


//metodo para inicializar
-(void) initialize{
    self.objeTaller = [Taler new];

}


//ocultar teclado
- (IBAction)hideKeyboard:(id)sender {
    [self.view endEditing:YES];
}



//entrda a crear
-(void) createTrabajo{
    NSString* marca = [self.txtmarca.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
     NSString* ano = [self.txtdetalle.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
     NSString* cliente = [self.txtdetalle.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
     NSString* descripcion = [self.txtdetalle.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
     NSString* montoTotal = [self.txtdetalle.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
   
    
    if(marca.length ==0 ||ano ==0 ||cliente ==0 ||descripcion ==0 ||montoTotal ==0){
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle: @"Error"message:@"Hay espacios en blanco" delegate:nil cancelButtonTitle:@"Aceptar" otherButtonTitles:nil, nil];
        [alert show];
    }else{
        
        //llenamos los objetos si no estan vacios
        self.objeTaller.marca=self.txtmarca.text;
        self.objeTaller.ano=[self.txtano.text intValue];
        self.objeTaller.cliente=self.txtcliente.text;
        self.objeTaller.descripcion=self.txtdetalle.text;
        self.objeTaller.montoTotal=[self.txttotal.text floatValue];
        
      //  NSDate *date= [NSDate date];
      //NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
       //[dateFormatter setDateFormat:@"yyyy-MM-dd"];
      //  NSString *dateString = [dateFormatter stringFromDate:date];
      //  NSDate *newDate = [dateFormatter dateFromString:dateString];
       // NSLog(@" nueva fecha %@", newDate);
        self.objeTaller.fechaTrabajo = [NSDate date];
       
        
        
        //llamamos as metodo guardar en la base de datos
        [self saveInDataBase:self.objeTaller];
        
        //nos devolvemos
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}


//metodo para guardar en la base de datos
-(void)saveInDataBase:(RLMObject*)newObject{
    RLMRealm *real = [RLMRealm defaultRealm];
    [real beginWriteTransaction];
    [real addObject:newObject];
    [real commitWriteTransaction];
}


//accion para guardar en la base de datos
- (IBAction)guardar:(id)sender {
    
    [self createTrabajo];
}
@end
