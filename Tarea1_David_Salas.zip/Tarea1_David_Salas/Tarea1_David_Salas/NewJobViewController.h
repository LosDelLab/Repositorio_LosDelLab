//
//  NewJobViewController.h
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/1/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Taler.h"



@interface NewJobViewController : UIViewController
@property(nonatomic,strong)Taler* objeTaller;

@property (weak, nonatomic) IBOutlet UITextField *txtmarca;

@property (weak, nonatomic) IBOutlet UITextField *txtano;

@property (weak, nonatomic) IBOutlet UITextField *txtcliente;

@property (weak, nonatomic) IBOutlet UITextView *txtdetalle;
@property (weak, nonatomic) IBOutlet UITextField *txttotal;

- (IBAction)guardar:(id)sender;

@end
