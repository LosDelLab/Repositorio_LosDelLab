//
//  WelcomeViewController.m
//  Tarea1_David_Salas
//
//  Created by Enrique on 6/29/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import "WelcomeViewController.h"
#import "NewJobViewController.h"
#import "HistorialViewController.h"

@interface WelcomeViewController ()

@end

@implementation WelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)showHistory:(id)sender {
    
    HistorialViewController* historial =[self.storyboard instantiateViewControllerWithIdentifier:@"HistorialViewController"];
    
    [self.navigationController pushViewController:historial animated:YES];
    
    
}


- (IBAction)addNewJob:(id)sender {
    
    
    NewJobViewController* newJoblView =[self.storyboard instantiateViewControllerWithIdentifier:@"NewJobViewController"];
  
    [self.navigationController pushViewController:newJoblView animated:YES];
}
@end
