//
//  HistorialTableViewCell.m
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/3/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import "HistorialTableViewCell.h"

@implementation HistorialTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
