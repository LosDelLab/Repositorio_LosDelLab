//
//  HistorialViewController.h
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/3/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Realm/Realm.h>

@interface HistorialViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) RLMResults* tallerArray;


- (IBAction)filtrarPorDia:(id)sender;


- (IBAction)filtrarPorAno:(id)sender;


- (IBAction)mostrarHistorial:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *txtfiltro;

@end
