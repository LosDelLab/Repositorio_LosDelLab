//
//  Taler.m
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/1/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import "Taler.h"


@implementation Taler

@end
