//
//  HistorialViewController.m
//  Tarea1_David_Salas
//
//  Created by Enrique on 7/3/15.
//  Copyright (c) 2015 david. All rights reserved.
//

#import "HistorialViewController.h"
#import "HistorialTableViewCell.h"
#import "Taler.h"
static int NUMBER_SECTION =1;
static NSString* CELL_IDENTIFIER =@"HistorialTableViewCell";
static int ZERO =0;

@interface HistorialViewController()



@end

@implementation HistorialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //llamamos al metodo inicializar
    [self initialize];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


//metodopara inicializar
-(void)initialize{
    UINib *nib = [UINib nibWithNibName:CELL_IDENTIFIER bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CELL_IDENTIFIER];

    
}

-(void)viewWillAppear:(BOOL)animated{
    
    //llamamos al metodo cargar trabajos
    [self.tableView reloadData];
}


//metodo para cargar los trbajos
-(void)loadTrabajos{
   
    RLMResults *trabajosTemp = [Taler allObjects];
    
    if (trabajosTemp.count>ZERO) {
    self.tallerArray = trabajosTemp;
    }else{
        // erro
          NSLog(@"Error al cargar los datos");
    }
  
}


//metodo para cargar los trbajos
-(void)loadTrabajosPorDia:(NSString*)filtroDia{
    
    
    RLMResults *trabajosTemp = [Taler allObjects];
   
    //NSPredicate *dia= [NSPredicate predicateWithFormat:@"fechaTrabajo= %@",filtroDia];
    
    //RLMResults *trabajosTemp = [Taler objectsWithPredicate:dia];

    if (trabajosTemp.count>ZERO) {
        self.tallerArray = trabajosTemp;
        
    
    }else{
        // erro
        NSLog(@"Error al cargar los datos");
    }
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 88;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return NUMBER_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.tallerArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    HistorialTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER];
     Taler* object = [self.tallerArray objectAtIndex:indexPath.row];
    
    cell.txtFecha.text = [NSString stringWithFormat:@"%@",object.fechaTrabajo];
    cell.txtMarca.text = object.marca;
    cell.txtCliente.text = object.cliente;
    cell.txtDetalle.text = object.descripcion;
    
    return cell;
}



- (IBAction)filtrarPorDia:(id)sender {
    
    [self loadTrabajosPorDia:self.txtfiltro.text];
    

}


- (IBAction)filtrarPorAno:(id)sender {
}


//metodo para mostrar todo el historial
- (IBAction)mostrarHistorial:(id)sender {
    
    [self loadTrabajos];
    [self.tableView reloadData];
}
@end
